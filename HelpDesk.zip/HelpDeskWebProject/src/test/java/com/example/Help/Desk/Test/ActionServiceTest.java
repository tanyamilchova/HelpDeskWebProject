package com.example.Help.Desk.Test;

import com.example.Help.Desk.Util;
import com.example.Help.Desk.model.DTOs.ActionInfoDTO;
import com.example.Help.Desk.model.DTOs.AddActionDTO;
import com.example.Help.Desk.model.entities.Action;
import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.entities.Project;
import com.example.Help.Desk.model.exceptions.BadRequestException;
import com.example.Help.Desk.model.exceptions.NotFoundException;
import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import com.example.Help.Desk.model.repositories.ActionRepository;
import com.example.Help.Desk.model.repositories.EmployeeRepository;
import com.example.Help.Desk.model.repositories.ProjectRepository;
import com.example.Help.Desk.service.ActionService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
public class ActionServiceTest {
    @InjectMocks
    private ActionService actionService;
    @Mock
    private EmployeeRepository employeeRepository;
    @Mock
    private ProjectRepository projectRepository;
    @Mock
    private ActionRepository actionRepository;
    @Mock
    private ModelMapper mapper;

    @Test
    public void testAddActionToProject() {
        long loggedId = 1L;
        long employeeId = 2;
        long projectId = 8;
        AddActionDTO addActionDTO = new AddActionDTO(Util.DESCRIPTION, Util.STATUS_OPEN, employeeId, projectId);
        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_LEAD);
        Employee employee = getEmployeeWithIdAndRole(employeeId, Util.TEAM_MEMBER);
        Project project = getProjectWithIdAndEmployee(projectId, logged);
        Action action = getAction(Util.DESCRIPTION, Util.STATUS_OPEN, employee, project);
        ActionInfoDTO expected = new ActionInfoDTO();

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(projectRepository.findById(projectId)).thenReturn(Optional.of(project));
        when(mapper.map(addActionDTO, Action.class)).thenReturn(action);
        when(mapper.map(action, ActionInfoDTO.class)).thenReturn(expected);

        ActionInfoDTO result = actionService.addActionToProject(loggedId, addActionDTO);

        assertEquals(expected, result);
    }

    private static Employee getEmployeeWithIdAndRole(long id, String role) {
        Employee employee = new Employee();
        employee.setId(id);
        employee.setRole(role);
        return employee;
    }
    private static Project getProjectWithIdAndEmployee(long id, Employee employee){
        Project project = new Project();
        project.setId(id);
        project.setEmployee(employee);
        return project;
    }
    private static Action getAction(String description, String status, Employee employee, Project project) {
        Action action = new Action();
        action.setDescription(description);
        action.setStatus(status);
        action.setProject(project);
        action.setEmployee(employee);
        return action;
    }

    @Test
    public void testAddActionToProjectUnauthorized() {
        long loggedId = 1L;
        long employeeId = 2;
        long projectId = 8;
        AddActionDTO addActionDTO = new AddActionDTO(Util.DESCRIPTION, Util.STATUS_OPEN, employeeId, projectId);
        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_MEMBER);

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));

        UnauthorizedException exception = assertThrows(UnauthorizedException.class,
                () ->  actionService.addActionToProject(loggedId, addActionDTO));

        assertEquals("Only " + Util.TEAM_LEAD + " can access this content.", exception.getMessage());
    }

    @Test
    public void testAddActionToProjectWrongEmployeeRole() {
        long loggedId = 1L;
        long employeeId = 2;
        long projectId = 8;
        AddActionDTO addActionDTO = new AddActionDTO(Util.DESCRIPTION, Util.STATUS_OPEN, employeeId, projectId);
        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_LEAD);
        Employee employee = getEmployeeWithIdAndRole(employeeId, Util.ADMIN);

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));

        BadRequestException exception = assertThrows(BadRequestException.class,
                () ->  actionService.addActionToProject(loggedId, addActionDTO));

        assertEquals("You can only add " + Util.TEAM_MEMBER + " to this position.", exception.getMessage());
    }

    @Test
    public void testEditAction() {
        long loggedId = 1L;
        long employeeId = 2;
        long projectId = 8;

        long actionId = 5;
        AddActionDTO addActionDTO = new AddActionDTO("New Description", "In progress", employeeId, projectId);
        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_MEMBER);
        Employee employee = getEmployeeWithIdAndRole(employeeId, Util.TEAM_MEMBER);
        Project project = getProjectWithIdAndEmployee(projectId, logged);
        Action action = new Action();
        action.setId(actionId);
        action.setEmployee(logged);
        ActionInfoDTO expected = new ActionInfoDTO();

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(projectRepository.findById(projectId)).thenReturn(Optional.of(project));
        when(actionRepository.findById(actionId)).thenReturn(Optional.of(action));
        when(mapper.map(addActionDTO, Action.class)).thenReturn(action);
        when(mapper.map(action, ActionInfoDTO.class)).thenReturn(expected);

        ActionInfoDTO result = actionService.editAction(loggedId, actionId, addActionDTO);

        assertEquals(expected, result);
    }

    @Test
    public void testEditActionProjectNotFound() {
        long loggedId = 1L;
        long employeeId = 2;
        long projectId = 8;
        long actionId = 5;

        AddActionDTO addActionDTO = new AddActionDTO("New Description", "In progress", employeeId, projectId);
        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_MEMBER);
        Employee employee = getEmployeeWithIdAndRole(employeeId, Util.TEAM_MEMBER);
        Action action = new Action();
        action.setId(actionId);
        action.setEmployee(logged);

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(projectRepository.findById(projectId)).thenReturn(Optional.empty());
        when(actionRepository.findById(actionId)).thenReturn(Optional.of(action));


        NotFoundException exception = assertThrows(NotFoundException.class,
                () ->  actionService.editAction(loggedId, actionId, addActionDTO));

        assertEquals("Resource not found.", exception.getMessage());
    }

    @Test
    public void testDeleteAction() {
        long loggedId = 1L;
        long actionId = 5;

        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_LEAD);
        Action action = new Action();
        action.setId(actionId);
        action.setEmployee(logged);

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(actionRepository.findById(actionId)).thenReturn(Optional.of(action));

        ResponseEntity<String> response = actionService.deleteAction(loggedId, actionId);

        assertEquals("Action deleted successfully", response.getBody());
        verify(actionRepository).findById(actionId);
        verify(actionRepository).delete(action);
    }

    @Test
    public void testDeleteActionUnauthorized() {
        long loggedId = 1L;
        long actionId = 5;

        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_MEMBER);
        Action action = new Action();
        action.setId(actionId);
        action.setEmployee(logged);

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(actionRepository.findById(actionId)).thenReturn(Optional.of(action));

        UnauthorizedException exception = assertThrows(UnauthorizedException.class,
                () ->  actionService.deleteAction(loggedId, actionId));

        assertEquals("Only " + Util.TEAM_LEAD + " can access this content.", exception.getMessage());
        verify(actionRepository, never()).delete(action);
    }

    @Test
    public void getActionById() {
        long loggedId = 1L;
        long actionId = 5;

        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_MEMBER);
        Action action = new Action();
        action.setId(actionId);
        action.setEmployee(logged);
        ActionInfoDTO expected = new ActionInfoDTO();

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(actionRepository.findById(actionId)).thenReturn(Optional.of(action));
        when(mapper.map(action, ActionInfoDTO.class)).thenReturn(expected);

        ActionInfoDTO result = actionService.getActionById(actionId, loggedId);

        assertEquals(expected, result);
    }

    @Test
    public void getActionByIdUnauthorized() {
        long loggedId = 1L;
        long actionId = 5;

        Employee logged = getEmployeeWithIdAndRole(loggedId, Util.TEAM_MEMBER);
        Action action = new Action();
        action.setId(actionId);
        action.setEmployee(getEmployeeWithIdAndRole(10, Util.TEAM_MEMBER));

        when(employeeRepository.findById(loggedId)).thenReturn(Optional.of(logged));
        when(actionRepository.findById(actionId)).thenReturn(Optional.of(action));

        UnauthorizedException exception = assertThrows(UnauthorizedException.class,
                () ->  actionService.getActionById(actionId, loggedId));

        assertEquals("You are not the owner of this action", exception.getMessage());
    }
}
