package com.example.Help.Desk;

public class Util {
    public  static final String USER="USER";
    public static final String ADMIN="ADMIN";
    public static final String EMAIL="EMAIL@abv.bg";
    public static final String NEW_EMAIL="NEW_EMAIL@abv.bg";
    public static final String FULL_NAME="FULL_NAME";
    public static final String PASSWORD="PASSWORD1a*11@@";
    public static final String NEW_PASSWORD="PASSWORD1a*11@@@";
    public static final String  WRONG_EMAIL="WRONG_EMAIL";
    public static final String  WRONG_PASSWORD="WRONG_PASSWORD";
    public static final String TEAM_MEMBER ="TEAM_MEMBER";
    public static final String TEAM_LEAD ="TEAM_LEAD";
    public static final long ADMIN_ID=1;
    public static final long ID=2;
    public static final String DESCRIPTION = "This is the description";
    public static final String STATUS_OPEN = "Open";


}
