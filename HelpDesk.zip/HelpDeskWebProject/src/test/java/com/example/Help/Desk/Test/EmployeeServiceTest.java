package com.example.Help.Desk.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.Help.Desk.Util;
import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.exceptions.BadRequestException;
import com.example.Help.Desk.model.exceptions.NotFoundException;
import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import com.example.Help.Desk.model.repositories.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class EmployeeServiceTest {

    @Mock
    EmployeeRepository employeeRepository;
    @InjectMocks
    com.example.Help.Desk.service.EmployeeService employeeService;
    @Mock
    private ModelMapper mapper;
    @Mock
    private JavaMailSender mailSender;
    @Mock
    private BCryptPasswordEncoder passwordEncoder;
    @Mock
    Util util;
    @BeforeEach
    void setUp() {
            MockitoAnnotations.openMocks(this);
        }



    @Test
    void testLogin_InvalidCredentials() {

        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setEmail(Util.EMAIL);
        loginDTO.setPassword(Util.WRONG_PASSWORD);
        Employee mockEmployee = new Employee();
        mockEmployee.setEmail(Util.EMAIL);
        mockEmployee.setPassword(passwordEncoder.encode(Util.PASSWORD));

        when(employeeRepository.findByEmail(Util.EMAIL)).thenReturn(Optional.of(mockEmployee));
        assertThrows(UnauthorizedException.class, () -> employeeService.login(loginDTO));
    }

    @Test
    public void testSuccessfulLogin() {

        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setEmail(Util.EMAIL);
        loginDTO.setPassword(Util.PASSWORD);

        Employee user = new Employee();
        user.setEmail(Util.EMAIL);
        user.setPassword(Util.PASSWORD);

        PersonInfoDTO expected=new PersonInfoDTO(1, Util.FULL_NAME);

        when(employeeRepository.findByEmail(loginDTO.getEmail())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())).thenReturn(true);
        when(employeeService.login(loginDTO)).thenReturn(expected);

        PersonInfoDTO result = employeeService.login(loginDTO);

        assertNotNull(result);
        assertEquals(expected, result);
    }
    @Test
    public void registerSuccessful() {
        RegisterEmployeeDTO registerEmployeeDTO = new RegisterEmployeeDTO();
        registerEmployeeDTO.setEmail(Util.EMAIL);
        registerEmployeeDTO.setFullName(Util.FULL_NAME);
        registerEmployeeDTO.setRole(Util.TEAM_MEMBER);

        Employee employee = new Employee();
        employee.setEmail(registerEmployeeDTO.getEmail());
        employee.setFullName(registerEmployeeDTO.getFullName());
        employee.setRole(registerEmployeeDTO.getRole());
        employee.setId(1);

        PersonInfoDTO expectedUser = new PersonInfoDTO();
        expectedUser.setId(employee.getId());
        expectedUser.setFullName(registerEmployeeDTO.getFullName());

        when(employeeRepository.existsByEmail(registerEmployeeDTO.getEmail())).thenReturn(false);
        when(mapper.map(registerEmployeeDTO, Employee.class)).thenReturn(employee);

        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);
        when(mapper.map(employee, PersonInfoDTO.class)).thenReturn(expectedUser);


        PersonInfoDTO result = employeeService.registerEmployee(registerEmployeeDTO);

        assertNotNull(result);
        assertEquals(expectedUser, result);
    }
    @Test
    public void registerEmailAlreadyExists() {

        RegisterEmployeeDTO registerEmployeeDTO = new RegisterEmployeeDTO();
        registerEmployeeDTO.setEmail(Util.EMAIL);

        when(employeeRepository.existsByEmail(registerEmployeeDTO.getEmail())).thenReturn(true);
        assertThrows(BadRequestException.class, () -> employeeService.registerEmployee(registerEmployeeDTO));
    }
    @Test
    public void changePasswordSuccessfully() {
        long userId = Util.ID;
        String currentPassword = Util.PASSWORD;
        String newPassword = Util.NEW_PASSWORD;

        ChangePassDTO changePassDTO = new ChangePassDTO();
        changePassDTO.setCurrentPassword(currentPassword);
        changePassDTO.setNewPassword(newPassword);
        changePassDTO.setConfirmNewPassword(newPassword);

        Employee employee = new Employee();
        employee.setId(userId);
        employee.setPassword(passwordEncoder.encode(currentPassword));

        when(employeeRepository.findById(userId)).thenReturn(Optional.of(employee));
        when(passwordEncoder.matches(currentPassword,employee.getPassword())).thenReturn(true);
        when(employeeRepository.save(employee)).thenReturn(employee);

        PersonInfoDTO expectedUser = new PersonInfoDTO();
        expectedUser.setId(userId);

        when(mapper.map(employee, PersonInfoDTO.class)).thenReturn(expectedUser);

        PersonInfoDTO result = employeeService.changePass(changePassDTO, userId);

        assertNotNull(result);
        assertEquals(userId, result.getId());
        assertEquals(passwordEncoder.encode(newPassword), employee.getPassword());
    }
    @Test
    public void changePasswordInvalidUserIdThrowsException() {

        long userId = Util.ID;
        String newPassword = Util.NEW_PASSWORD;

        ChangePassDTO changePassData = new ChangePassDTO();
        changePassData.setNewPassword(newPassword);

        when(employeeRepository.findById(userId)).thenReturn(Optional.empty());
        assertThrows(NotFoundException.class, () -> employeeService.changePass(changePassData, userId));
    }

    @Test
    public void editProfileSuccessfully() {

        long userId = Util.ID;
        String newEmail = Util.NEW_EMAIL;

        EditEmployeeDTO editEmployeeDTO = new EditEmployeeDTO();
        editEmployeeDTO.setEmail(newEmail);
        editEmployeeDTO.setFullName(Util.FULL_NAME);

        Employee admin=new Employee();
        admin.setId(5);
        admin.setRole(Util.ADMIN);

        Employee employee = new Employee();
        employee.setId(userId);
        employee.setEmail(Util.EMAIL);
        PersonInfoDTO expected = new PersonInfoDTO();
        expected.setId(userId);

        when(employeeRepository.findById(admin.getId())).thenReturn(Optional.of(admin));
        when(employeeRepository.existsByEmail(newEmail)).thenReturn(false);
        when(employeeRepository.findById(userId)).thenReturn(Optional.of(employee));
        when(mapper.map(employee, PersonInfoDTO.class)).thenReturn(expected);

        PersonInfoDTO result = employeeService.editEmployee(editEmployeeDTO,admin.getId(), userId);

        assertNotNull(result);
        assertEquals(expected, result);
    }

    @Test
    public void deleteEmployeeValidPassword() {

        long employeeId = Util.ID;
        String password = Util.PASSWORD;

        PersonInfoDTO userPasswordDTO = new PersonInfoDTO();
        userPasswordDTO.setId(employeeId);
        Employee admin=new Employee();
        admin.setRole(Util.ADMIN);

        Employee employee = new Employee();
        employee.setId(employeeId);
        employee.setPassword(passwordEncoder.encode(password));

        when(employeeRepository.findById(admin.getId())).thenReturn(Optional.of(admin));
        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        assertDoesNotThrow(() -> employeeService.deleteEmployee( employeeId, admin.getId()));
    }
    @Test
    public void deleteUnauthorisedThrowsException() {

        long employeeId = Util.ID;
        Employee member=new Employee();
        member.setRole(Util.USER);
        member.setId(Util.ID);

        when(employeeRepository.findById(member.getId())).thenReturn(Optional.of(member));
                assertThrows(UnauthorizedException.class, () -> employeeService.deleteEmployee(employeeId, member.getId()));
    }
    @Test
    public void editProfileEmailAlreadyExists1() {
        long userId = Util.ID;
        EditEmployeeDTO editEmployeeDTO = new EditEmployeeDTO();
        editEmployeeDTO.setEmail("Abv@gmail.com");
        editEmployeeDTO.setFullName(Util.FULL_NAME);

        Employee admin = new Employee();
        admin.setId(Util.ADMIN_ID);
        admin.setRole(Util.ADMIN);

        Employee employee = new Employee();
        employee.setId(userId);
        employee.setEmail(Util.EMAIL);

        when(employeeRepository.findById(admin.getId())).thenReturn(Optional.of(admin));
        when(employeeRepository.findById(employee.getId())).thenReturn(Optional.of(employee));
        when(employeeRepository.existsByEmail(editEmployeeDTO.getEmail())).thenReturn(true);

        assertNotEquals(editEmployeeDTO.getEmail(),employee.getEmail());
        assertThrows(UnauthorizedException.class, () -> employeeService.editEmployee(editEmployeeDTO,admin.getId(), userId));
    }
    @Test
    public void testGetEmployeeById() {
        long id = Util.ID;

        Employee admin = new Employee();
        admin.setId(Util.ADMIN_ID);
        admin.setRole(Util.ADMIN);
        PersonInfoDTO expected = new PersonInfoDTO();

        Employee employee = new Employee();
        employee.setId(id);

        when(employeeRepository.findById(admin.getId())).thenReturn(Optional.of(admin));
        when(employeeRepository.findById(employee.getId())).thenReturn(Optional.of(employee));
        when(mapper.map(employee, PersonInfoDTO.class)).thenReturn(expected);
        PersonInfoDTO result = employeeService.getEmployeeById(id, admin.getId());

        assertEquals(expected, result);
    }
}



