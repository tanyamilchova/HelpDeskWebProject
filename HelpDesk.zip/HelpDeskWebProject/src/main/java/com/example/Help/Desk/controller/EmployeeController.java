package com.example.Help.Desk.controller;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import com.example.Help.Desk.service.EmployeeService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeController extends AbstractController{
    @Autowired
    private EmployeeService employeeService;
    @Value("${admin.password}")
    private static String PASSWORD;
    @PostMapping("/admins")
    public PersonInfoDTO registerAdmin(@Valid @RequestBody RegisterAdminDTO registerAdminDTO){
        authorizeRequest(registerAdminDTO);
        return employeeService.registerAdmin(registerAdminDTO);
    }

    private void authorizeRequest(RegisterAdminDTO registerAdminDTO) {
        if (registerAdminDTO.getPassword().equals(PASSWORD)) {
            throw new UnauthorizedException("Wrong credentials");
        }
    }
    @PostMapping("/login")
    public PersonInfoDTO login(@RequestBody LoginDTO loginDTO, HttpSession session) {
        PersonInfoDTO infoDTO = employeeService.login(loginDTO);
        session.setAttribute(LOGGED, true);
        session.setAttribute(LOGGED_ID, infoDTO.getId());
        return infoDTO;
    }

    @PutMapping("/change-password")
    public PersonInfoDTO changePassword(@Valid @RequestBody ChangePassDTO changePassDTO, HttpSession session) {
        long id = getLoggedId(session);
        return employeeService.changePass(changePassDTO, id);
    }


    @PostMapping()
    public PersonInfoDTO registerEmployee(@Valid @RequestBody RegisterEmployeeDTO registerEmployeeDTO, HttpSession session){
        long loggedId = getLoggedId(session);
        return employeeService.registerEmployee(registerEmployeeDTO, loggedId);
    }
    @GetMapping("/{id}")
    public PersonInfoDTO getEmployeeById(@PathVariable long id, HttpSession session){
        long loggedId=getLoggedId(session);
        return employeeService.getEmployeeById(id,loggedId);
    }

    @GetMapping()
    public Page<PersonInfoDTO> allEmployee(@RequestParam (defaultValue = "0")int page,
                                           @RequestParam (defaultValue = "10")int size, HttpSession session){
        long loggedId = getLoggedId(session);
        return employeeService.getAllEmployees(page, size, loggedId);
    }
    @PutMapping("/{id}")
    public PersonInfoDTO editEmployee(@Valid @RequestBody  EditEmployeeDTO editEmployeeDTO,
                                          @PathVariable ("id") long employeeId,
                                          HttpSession session){

        long loggedId=getLoggedId(session);
        return employeeService.editEmployee(editEmployeeDTO, loggedId, employeeId);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable ("id") long employeeId, HttpSession session){
        long userId=getLoggedId(session);
        employeeService.deleteEmployee(employeeId,userId);
        return  ResponseEntity.ok("Account deleted");
    }
    @PostMapping("/logout")
    public ResponseEntity<String> logout( HttpSession session) {
        if(getLoggedId(session) > 0) {
            session.invalidate();
        }
        return ResponseEntity.ok("Logged out successfully");
    }

}
