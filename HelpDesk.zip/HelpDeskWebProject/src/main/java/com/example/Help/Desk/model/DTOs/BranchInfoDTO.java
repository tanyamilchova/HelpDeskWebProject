package com.example.Help.Desk.model.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BranchInfoDTO {

    private long id;
    private String name;
    private String description;
    private String status;
    private long projectId;
}
