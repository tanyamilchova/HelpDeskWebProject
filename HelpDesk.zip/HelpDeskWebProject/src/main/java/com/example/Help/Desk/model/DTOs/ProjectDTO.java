package com.example.Help.Desk.model.DTOs;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProjectDTO {
    @NotBlank
    private String name;
    @NotBlank
    private String description;
    @NotNull(message = "Team Lead ID is required")
    @Positive(message = "Team Lead ID must be a positive number")
    private Long teamLeadId;
}



