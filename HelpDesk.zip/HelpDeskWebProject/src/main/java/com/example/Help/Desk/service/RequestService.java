package com.example.Help.Desk.service;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.entities.Project;
import com.example.Help.Desk.model.entities.Request;
import com.example.Help.Desk.model.repositories.EmployeeRepository;
import com.example.Help.Desk.model.repositories.ProjectRepository;
import com.example.Help.Desk.model.repositories.RequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class RequestService extends AbstractService{
    @Autowired
    RequestRepository requestRepository;
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    ProjectRepository projectRepository;
    public RequestInfoDTO addRequest(AddRequestDTO addRequestDTO, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_MEMBER);
        Employee teamMember=getIfPresent(employeeRepository.findById(loggedId));
        Request request = new Request();
        request.setStatus(addRequestDTO.getDescription());
        request.setDescription(addRequestDTO.getDescription());
        request.setDateSubmitted(LocalDateTime.now());

        Project project=getIfPresent(projectRepository.findById(addRequestDTO.getProjectId()));
        request.setProject(project);
        request.setEmployee(teamMember);
        requestRepository.save(request);

        RequestInfoDTO requestInfoDTO=mapper.map(request, RequestInfoDTO.class);
        requestInfoDTO.setProjectId(project.getId());
        requestInfoDTO.setTeamMemberId(teamMember.getId());
        return requestInfoDTO;
    }
    public void deleteRequest(long requestId, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_MEMBER);
        Request request=getIfPresent(requestRepository.findById(requestId));
        requestRepository.delete(request);
    }

    public RequestInfoDTO editRequest(long requestId, long loggedId, EditRequestDTO editRequestDTO) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_MEMBER);
        Request request=getIfPresent(requestRepository.findById(requestId));
        Project project=getIfPresent(projectRepository.findById(editRequestDTO.getProjectId()));
        Employee teamMember=getIfPresent(employeeRepository.findById(editRequestDTO.getTeamMemberId()));
        request.setStatus(editRequestDTO.getStatus());
        request.setDescription(editRequestDTO.getDescription());
        request.setProject(project);
        request.setEmployee(teamMember);
        requestRepository.save(request);

        return mapper.map(request,RequestInfoDTO.class);
    }
}
