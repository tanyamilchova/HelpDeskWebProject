package com.example.Help.Desk.controller;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.service.EmployeeService;
import com.example.Help.Desk.service.RequestService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/requests")
public class RequestController extends AbstractController{
    @Autowired
    RequestService requestService;
    @Autowired
    private EmployeeService employeeService;
    @PostMapping()
    public RequestInfoDTO addRequest(@Valid @RequestBody AddRequestDTO addRequestDTO, HttpSession session){
        long loggedId=getLoggedId(session);
        return requestService.addRequest(addRequestDTO,loggedId);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRequest(@PathVariable ("id") long requestId,HttpSession session){
        long loggedId=getLoggedId(session);
        requestService.deleteRequest(requestId,loggedId);
        return ResponseEntity.ok("Request deleted");
    }
    @PutMapping("/{id}")
    public RequestInfoDTO editRequest(@PathVariable ("id")long requestId,
                                      @Valid @RequestBody EditRequestDTO editRequestDTO,HttpSession session){
        long loggedId=getLoggedId(session);
        return requestService.editRequest(requestId,loggedId,editRequestDTO);
    }
}
