package com.example.Help.Desk.model.repositories;

import com.example.Help.Desk.model.entities.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface RequestRepository extends JpaRepository<Request,Long> {
    Optional<Request> findById(long id);
}
