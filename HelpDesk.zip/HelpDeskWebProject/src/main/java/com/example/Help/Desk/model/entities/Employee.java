package com.example.Help.Desk.model.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Entity(name = "employees")
@Table
@Getter
@Setter
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "full_name")
    private String fullName;
    @Column
    private String password;
    @Column
    private String email;
    @Column
    private String role;

    @OneToMany(mappedBy = "employee")
    private List<Project>projects;

    @OneToMany(mappedBy = "employee")
    private List<Action>actions;

    @OneToMany(mappedBy = "employee")
    private List<Request>requests;

}
