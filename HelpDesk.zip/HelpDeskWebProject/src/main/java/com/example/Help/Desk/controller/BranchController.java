package com.example.Help.Desk.controller;

import com.example.Help.Desk.model.DTOs.BranchInfoDTO;
import com.example.Help.Desk.model.DTOs.CreateBranchDTO;
import com.example.Help.Desk.model.DTOs.EditBranchDTO;
import com.example.Help.Desk.service.BranchService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class BranchController extends AbstractController{
    @Autowired
    BranchService branchService;
    @PostMapping("/branches")
    public BranchInfoDTO createProject(@Valid @RequestBody CreateBranchDTO createProjectDTO, HttpSession session){
            long loggedId = getLoggedId(session);
            return branchService.createBranch(createProjectDTO, loggedId);
        }


        @PutMapping("/branches/{id}")
        public BranchInfoDTO editBranch(@PathVariable("id")long branchId,
                                        @Valid @RequestBody EditBranchDTO editBranchDTO, HttpSession session){
            long loggedId=getLoggedId(session);
            return branchService.editBranch(branchId,loggedId,editBranchDTO);
        }
        @DeleteMapping("/branches/{id}")
        public ResponseEntity<String> deleteBranch(@PathVariable ("id") long branchId, HttpSession session){
            long loggedId=getLoggedId(session);
            branchService.deleteBranch(branchId,loggedId);
            return ResponseEntity.ok("Request deleted");
        }

        @GetMapping("/branches/{id}")
        public BranchInfoDTO getBranchById(@PathVariable long id, HttpSession session){
            long loggedId=getLoggedId(session);
            return branchService.getBranchById(id,loggedId);
        }


        @GetMapping("/projects/{id}/branches")
        public Page<BranchInfoDTO> allBranches(@PathVariable("id") long projectId,
                                                @RequestParam (defaultValue = "0")int page,
                                               @RequestParam (defaultValue = "10")int size, HttpSession session){
            long loggedId = getLoggedId(session);
            return branchService.getAllBranches(page, size, loggedId,projectId);
        }
}
