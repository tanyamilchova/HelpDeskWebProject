package com.example.Help.Desk.service;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.model.entities.Project;
import com.example.Help.Desk.model.entities.ProjectBranch;
import com.example.Help.Desk.model.repositories.BranchRepository;
import com.example.Help.Desk.model.repositories.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class BranchService extends AbstractService{
    @Autowired
    BranchRepository branchRepository;
    @Autowired
    ProjectRepository projectRepository;
    public BranchInfoDTO createBranch(CreateBranchDTO createBranchDTO, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_LEAD);

        ProjectBranch branch=new ProjectBranch();
        branch.setName(createBranchDTO.getName());
        branch.setDescription(createBranchDTO.getDescription());
        branch.setStatus(createBranchDTO.getStatus());
        Project project=getIfPresent(projectRepository.findById(createBranchDTO.getProjectId()));
        branch.setProject(project);
        branchRepository.save(branch);
        return mapper.map(branch,BranchInfoDTO.class);
    }

    public BranchInfoDTO editBranch(long branchId, long loggedId, EditBranchDTO edirBranchDTO) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_LEAD);
        ProjectBranch branch=getIfPresent(branchRepository.findById(branchId));
        branch.setName(edirBranchDTO.getName());
        branch.setDescription(edirBranchDTO.getDescription());
        branch.setStatus(edirBranchDTO.getStatus());
        branchRepository.save(branch);
        return mapper.map(branch,BranchInfoDTO.class);
    }

    public void deleteBranch(long branchId, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_LEAD);
        ProjectBranch branch=getIfPresent(branchRepository.findById(loggedId));
        branchRepository.delete(branch);
    }

    public BranchInfoDTO getBranchById(long id, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_LEAD);
        ProjectBranch branch=getIfPresent(branchRepository.findById(id));
        return mapper.map(branch,BranchInfoDTO.class);
    }

    public Page<BranchInfoDTO> getAllBranches(int page, int size,  long loggedId,long projectId) {
        authorizeEmployee(loggedId,RoleTypes.TEAM_LEAD);
        Pageable pageable = PageRequest.of(page,size);
        return branchRepository.getAllBranchesInfo(projectId,pageable)
                .map(branch -> mapper.map(branch, BranchInfoDTO.class));
    }
}
