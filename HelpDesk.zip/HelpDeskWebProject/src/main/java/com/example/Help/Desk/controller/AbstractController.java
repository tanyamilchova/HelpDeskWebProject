package com.example.Help.Desk.controller;

import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.*;
@RestController
public abstract class AbstractController {

    public static final String LOGGED="LOGGED";
    public static final String LOGGED_ID="LOGGED_ID";
    protected long getLoggedId(HttpSession session){
        if(session.getAttribute(LOGGED_ID)==null){
            throw new UnauthorizedException("You have to login first");
        }
        return (long) session.getAttribute(LOGGED_ID);
    }
}
