package com.example.Help.Desk.model.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ActionInfoDTO {
  private long id;
  private String description;
  private String status;
  private long projectId;
  private long employeeId;
}
