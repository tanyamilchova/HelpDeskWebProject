package com.example.Help.Desk.model.repositories;

import com.example.Help.Desk.model.entities.Project;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;
@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {
    Optional<Project> findById(long id);
    @Query(value = "SELECT * FROM projects", nativeQuery = true)
    Page<Project> getAllProjectsInfo(Pageable pageable);
}
