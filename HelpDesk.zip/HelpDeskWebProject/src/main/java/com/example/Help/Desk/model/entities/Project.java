package com.example.Help.Desk.model.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Entity(name = "projects")
@Table
@Getter
@Setter
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column
    private String name;
    @Column
    private String description;

    @ManyToOne
    @JoinColumn(name = "team_lead_id")
    private Employee employee;

    @OneToMany(mappedBy = "project")
    private List<Action> actions;

    @OneToMany(mappedBy = "project")
    private List<Request> requests;

    @OneToMany(mappedBy = "project")
    private List<ProjectBranch> projectBranches;
}
