package com.example.Help.Desk.model.repositories;

import com.example.Help.Desk.model.entities.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Long> {
    Optional<Employee>findByEmail(String email);
    boolean existsByEmail(String email);
    Optional<Employee>findById(long id);
    @Query(value = "SELECT * FROM employees", nativeQuery = true)
    Page<Employee> getAllEmployeeInfo(Pageable pageable);
}
