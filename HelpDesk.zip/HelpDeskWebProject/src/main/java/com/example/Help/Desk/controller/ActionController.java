package com.example.Help.Desk.controller;

import com.example.Help.Desk.model.DTOs.ActionInfoDTO;
import com.example.Help.Desk.model.DTOs.AddActionDTO;
import com.example.Help.Desk.service.ActionService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class ActionController extends AbstractController{
    @Autowired
    ActionService actionService;
    @PostMapping("/actions")
    public ActionInfoDTO addActionToProject(@Valid @RequestBody AddActionDTO addActionDTO, HttpSession session) {
        long loggedId = getLoggedId(session);
        return actionService.addActionToProject(loggedId, addActionDTO);
    }

    @PutMapping("/actions/{id}")
    public ActionInfoDTO editAction(@Valid @RequestBody AddActionDTO addActionDTO,
                                    @PathVariable ("id") long actionId, HttpSession session) {
        long loggedId = getLoggedId(session);
        return actionService.editAction(loggedId, actionId, addActionDTO);
    }

    @DeleteMapping("/actions/{id}")
    public ResponseEntity<String> deleteAction(@PathVariable ("id") long actionId, HttpSession session) {
        long loggedId = getLoggedId(session);
        return actionService.deleteAction(loggedId, actionId);
    }

    @GetMapping("/actions/{id}")
    public ActionInfoDTO getActionById(@PathVariable long id, HttpSession session){
        long loggedId=getLoggedId(session);
        return actionService.getActionById(id, loggedId);
    }

    @GetMapping("/projects/{id}/actions")
    public Page<ActionInfoDTO> getAllActionsByProject(@RequestParam (defaultValue = "0")int page,
                                                      @RequestParam (defaultValue = "10")int size,
                                                      @PathVariable("id") long projectId,
                                                      HttpSession session){
        long loggedId = getLoggedId(session);
        return actionService.getAllActionsByProject(page, size, loggedId, projectId);
    }
}
