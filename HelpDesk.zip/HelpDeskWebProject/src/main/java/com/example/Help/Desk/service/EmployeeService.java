package com.example.Help.Desk.service;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.exceptions.BadRequestException;
import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import org.apache.commons.text.CharacterPredicates;
import org.apache.commons.text.RandomStringGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmployeeService extends AbstractService{
    @Autowired
    private JavaMailSender mailSender;

    public PersonInfoDTO registerAdmin(RegisterAdminDTO registerAdminDTO) {
        RegisterEmployeeDTO registerDTO = mapper.map(registerAdminDTO, RegisterEmployeeDTO.class);
        registerDTO.setRole(RoleTypes.ADMIN.toString());
        return registerEmployee(registerDTO);
    }

    public PersonInfoDTO login(LoginDTO loginDTO) {
        Optional<Employee> opt = employeeRepository.findByEmail(loginDTO.getEmail());
        Employee employee = opt.orElseThrow(() -> new UnauthorizedException("Wrong credentials."));
        checkEncodedPassword(loginDTO.getPassword(), employee.getPassword());
        return mapper.map(employee,PersonInfoDTO.class);
    }

    public PersonInfoDTO changePass(ChangePassDTO changePassDTO, long id) {
        Employee employee= getIfPresent(employeeRepository.findById(id));
        checkEncodedPassword(changePassDTO.getCurrentPassword(), employee.getPassword());
            if(changePassDTO.getNewPassword().equals(changePassDTO.getConfirmNewPassword())){
                employee.setPassword(passwordEncoder.encode(changePassDTO.getNewPassword()));
                employeeRepository.save(employee);
                return mapper.map(employee,PersonInfoDTO.class);
            }else {
                throw new BadRequestException("Password mismatch");
            }
    }

    public PersonInfoDTO registerEmployee(RegisterEmployeeDTO registerEmployeeDTO, long loggedId) {
        authorizeEmployee(loggedId, RoleTypes.ADMIN);
        return registerEmployee(registerEmployeeDTO);
    }
    public PersonInfoDTO registerEmployee(RegisterEmployeeDTO registerEmployeeDTO) {

        if (employeeRepository.existsByEmail(registerEmployeeDTO.getEmail())) {
            throw new BadRequestException("Email already exist");
        }
        Employee employee = mapper.map(registerEmployeeDTO, Employee.class);
        String password = generatePassword();
        employee.setPassword(passwordEncoder.encode(password));

        employeeRepository.save(employee);
        sendConfirmationEmail(employee.getEmail(), password);
        return mapper.map(employee, PersonInfoDTO.class);
    }

    private String generatePassword() {
        RandomStringGenerator generator = new RandomStringGenerator.Builder()
                .withinRange('0', 'z')
                .filteredBy(CharacterPredicates.LETTERS, CharacterPredicates.DIGITS)
                .build();
        return generator.generate(12);
    }

    private void sendConfirmationEmail(String email, String password){
        SimpleMailMessage message =new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Welcome to Help Desk");
        message.setText("Welcome to the Help Desk Service Platform. Your credentials are: \n" +
                "\temail:" + email + "\n" +
                "\tpassword:" + password + "\n" +
                "Use them to log into your account." + "\n\n" +
                "Best regards,\n" +
                "Admin Team");
        new Thread(()->  mailSender.send(message)).start();
    }


    public Page<PersonInfoDTO> getAllEmployees(int page, int size, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Pageable pageable = PageRequest.of(page,size);
        return employeeRepository.getAllEmployeeInfo(pageable)
                .map(employee -> mapper.map(employee, PersonInfoDTO.class));
    }

    public PersonInfoDTO getEmployeeById(long id, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Employee employee= getIfPresent(employeeRepository.findById(id));
        return mapper.map(employee,PersonInfoDTO.class);
    }

    public PersonInfoDTO editEmployee(EditEmployeeDTO editEmployeeDTO, long loggedId, long employeeId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Employee employee= getIfPresent(employeeRepository.findById(employeeId));
        String email = editEmployeeDTO.getEmail();
        if (employeeRepository.existsByEmail(email) && !employee.getEmail().equals(email)) {
            throw new UnauthorizedException("Email already exist");
        }
        employee.setEmail(email);
        employee.setRole(editEmployeeDTO.getRole());
        employee.setFullName(editEmployeeDTO.getFullName());

        employeeRepository.save(employee);
        return mapper.map(employee, PersonInfoDTO.class);
    }

    public void deleteEmployee(long employeeId, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Employee employee=getIfPresent(employeeRepository.findById(employeeId));
        employeeRepository.delete(employee);
    }
}
