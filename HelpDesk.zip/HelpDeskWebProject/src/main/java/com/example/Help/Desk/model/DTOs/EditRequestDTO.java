package com.example.Help.Desk.model.DTOs;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EditRequestDTO {
    @NotBlank
    private String description;
    @NotBlank
    private String status;
    @NotNull(message = "Project id is required")
    @Positive(message = "Project id must be a positive number")
    private long projectId;
    @NotNull(message = "Employee id is required")
    @Positive(message = "Employee id must be a positive number")
    private long teamMemberId;
}



