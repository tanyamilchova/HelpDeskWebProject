package com.example.Help.Desk.controller;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.service.ProjectService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/projects")
public class ProjectController extends AbstractController{
    @Autowired
    protected ProjectService projectService;

    @PostMapping()
    public ProjectInfoDTO createProject(@Valid @RequestBody ProjectDTO createProjectDTO, HttpSession session){
        long loggedId = getLoggedId(session);//TODO
        return projectService.createProject(createProjectDTO, loggedId);
    }

    @PutMapping("/{id}")
    public ProjectInfoDTO editProject(@Valid @PathVariable ("id")long projectId,
                                      @RequestBody ProjectDTO editProjectDTO, HttpSession session){
        long loggedId=getLoggedId(session);
        return projectService.editProject(projectId,loggedId,editProjectDTO);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProject(@Valid @PathVariable ("id") long projectId, HttpSession session){
        long loggedId=getLoggedId(session);
        projectService.deleteProject(projectId,loggedId);
        return ResponseEntity.ok("Request deleted");
    }

    @GetMapping("/{id}")
    public ProjectInfoDTO getProjectById(@PathVariable long id, HttpSession session){
        long loggedId=getLoggedId(session);
        return projectService.getProjectById(id,loggedId);
    }

    @GetMapping()
    public Page<ProjectInfoDTO> allProjects(@RequestParam (defaultValue = "0")int page,
                                           @RequestParam (defaultValue = "10")int size, HttpSession session){
        long loggedId = getLoggedId(session);
        return projectService.getAllProjects(page, size, loggedId);
    }
}
