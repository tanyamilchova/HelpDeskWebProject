package com.example.Help.Desk.model.repositories;

import com.example.Help.Desk.model.entities.Action;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface ActionRepository extends JpaRepository<Action,Long> {
    Optional<Action>findById(long id);

    @Query(value = "SELECT * FROM actions WHERE project_id = :projectId", nativeQuery = true)
    Page<Action> findAllByProject(Pageable pageable, long projectId);

}