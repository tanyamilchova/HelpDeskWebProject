package com.example.Help.Desk.service;

import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.exceptions.BadRequestException;
import com.example.Help.Desk.model.exceptions.NotFoundException;
import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import com.example.Help.Desk.model.repositories.EmployeeRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public abstract class AbstractService {
    @Autowired
    protected EmployeeRepository employeeRepository;
    @Autowired
    protected ModelMapper mapper;
    @Autowired
    protected BCryptPasswordEncoder passwordEncoder;
    protected enum RoleTypes{
        ADMIN, TEAM_LEAD, TEAM_MEMBER, NETWORK_MANAGER
    }
    public static final String LOGGED="LOGGED";
    public static final String LOGGED_ID="LOGGED_ID";

    public <T> T getIfPresent(Optional<T> opt){
        if(opt.isEmpty()){
            throw new NotFoundException("Resource not found.");
        }
        return opt.get();
    }
    public void checkEncodedPassword(String rawPass, String encodedPass){
        if(!passwordEncoder.matches(rawPass, encodedPass)){
            throw new UnauthorizedException("Wrong credentials.");
        }
    }

protected void authorizeEmployee(long loggedId, RoleTypes roleForAccess) {
    Employee logged = getIfPresent(employeeRepository.findById(loggedId));
    String loggedRole = logged.getRole();
    if(!loggedRole.equalsIgnoreCase(roleForAccess.toString())) {
        if (!loggedRole.equalsIgnoreCase(RoleTypes.NETWORK_MANAGER.toString())) {
            throw new UnauthorizedException("Only " + roleForAccess + " can access this content.");
        }
    }
}
    public Employee getValidEmployeeForPosition(long employeeId, RoleTypes role) {
        Employee employee = getIfPresent(employeeRepository.findById(employeeId));
        if(!employee.getRole().equalsIgnoreCase(role.toString())){
            throw new BadRequestException("You can only add " + role + " to this position.");
        }
        return employee;
    }
}
