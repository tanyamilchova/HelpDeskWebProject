package com.example.Help.Desk.model.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "project_branches")
@Getter
@Setter
public class ProjectBranch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column
    private String name;
    @Column
    private String description;
    @Column
    private String status;

    @ManyToOne
    @JoinColumn(name = "project_id")
    private Project project;
}
