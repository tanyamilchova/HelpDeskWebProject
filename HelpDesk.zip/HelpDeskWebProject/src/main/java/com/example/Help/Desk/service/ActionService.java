package com.example.Help.Desk.service;

import com.example.Help.Desk.model.DTOs.ActionInfoDTO;
import com.example.Help.Desk.model.DTOs.AddActionDTO;
import com.example.Help.Desk.model.entities.Action;
import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.entities.Project;
import com.example.Help.Desk.model.exceptions.UnauthorizedException;
import com.example.Help.Desk.model.repositories.ActionRepository;
import com.example.Help.Desk.model.repositories.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ActionService extends AbstractService {
    @Autowired
    private ProjectRepository projectRepository;
    @Autowired
    private ActionRepository actionRepository;
    public ActionInfoDTO addActionToProject(long loggedId,  AddActionDTO addActionDTO) {
        authorizeEmployee(loggedId, RoleTypes.TEAM_LEAD);

        Employee employee = getValidEmployeeForPosition(addActionDTO.getEmployeeId(), RoleTypes.TEAM_MEMBER);
        Project project = getProjectIfAuthorized(loggedId, addActionDTO.getProjectId());
        Action action = mapper.map(addActionDTO, Action.class);

        action.setEmployee(employee);
        action.setProject(project);
        actionRepository.save(action);

        ActionInfoDTO actionInfoDTO = mapper.map(action, ActionInfoDTO.class);
        actionInfoDTO.setProjectId(addActionDTO.getProjectId());
        actionInfoDTO.setEmployeeId(employee.getId());
        return actionInfoDTO;
    }

    public ActionInfoDTO editAction(long loggedId, long actionId, AddActionDTO addActionDTO) {
        Action action = getIfPresent(actionRepository.findById(actionId));
        authorizeEmployeeToEditAction(loggedId, action.getEmployee().getId());
        Employee employee = getValidEmployeeForPosition(addActionDTO.getEmployeeId(), RoleTypes.TEAM_MEMBER);
        Project project = getIfPresent(projectRepository.findById(addActionDTO.getProjectId()));

        action.setDescription(addActionDTO.getDescription());
        action.setStatus(addActionDTO.getStatus());
        action.setEmployee(employee);
        action.setProject(project);
        actionRepository.save(action);

        ActionInfoDTO actionInfoDTO = mapper.map(action, ActionInfoDTO.class);
        actionInfoDTO.setProjectId(addActionDTO.getProjectId());
        actionInfoDTO.setEmployeeId(employee.getId());

        return actionInfoDTO;
    }


    private Project getProjectIfAuthorized(long loggedId, long projectId) {
        Project project = getIfPresent(projectRepository.findById(projectId));
        if (project.getEmployee().getId() != loggedId) {
            throw new UnauthorizedException("You are not the team lead of this project.");
        }
        return project;
    }

    private void authorizeEmployeeToEditAction(long loggedId, long actionOwnerId) {
        Employee employee = getIfPresent(employeeRepository.findById(loggedId));
        String role = employee.getRole();
        if(!role.equalsIgnoreCase(RoleTypes.TEAM_LEAD.toString())
                && !role.equalsIgnoreCase(RoleTypes.NETWORK_MANAGER.toString())) {
            if(actionOwnerId != loggedId) {
                throw new UnauthorizedException("You are not the owner of this action");
            }
        }
    }

    public ResponseEntity<String> deleteAction(long loggedId, long actionId) {
        authorizeEmployee(loggedId, RoleTypes.TEAM_LEAD);
        Action action = getIfPresent(actionRepository.findById(actionId));
        actionRepository.delete(action);
        return ResponseEntity.ok("Action deleted successfully");
    }
    public ActionInfoDTO getActionById(long actionId, long loggedId) {
            Action action = getIfPresent(actionRepository.findById(actionId));
            authorizeEmployeeToEditAction(loggedId, action.getEmployee().getId());
            return mapper.map(action, ActionInfoDTO.class);
        }

    public Page<ActionInfoDTO> getAllActionsByProject(int page, int size, long loggedId, long projectId) {
        authorizeEmployee(loggedId, RoleTypes.TEAM_LEAD);

        Pageable pageable = PageRequest.of(page, size);
        return actionRepository.findAllByProject(pageable, projectId)
                .map(action -> mapper.map(action, ActionInfoDTO.class));
    }
}
