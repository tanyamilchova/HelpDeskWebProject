package com.example.Help.Desk.model.repositories;

import com.example.Help.Desk.model.entities.ProjectBranch;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface BranchRepository extends JpaRepository<ProjectBranch,Long> {
    Optional<ProjectBranch> findById(long id);
    @Query(value = "SELECT * FROM project_branches where project_id=:projectId", nativeQuery = true)
    Page<ProjectBranch> getAllBranchesInfo(long projectId, Pageable pageable);
}
