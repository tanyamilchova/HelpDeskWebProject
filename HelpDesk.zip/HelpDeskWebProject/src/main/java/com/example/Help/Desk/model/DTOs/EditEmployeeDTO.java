package com.example.Help.Desk.model.DTOs;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EditEmployeeDTO {
    @NotBlank
    @Pattern(regexp = "^[A-Za-z]{3,}\\s[A-Za-z]{3,}$", message = "Invalid full name")
    private String fullName;
    @NotBlank
    @Email(message = "Invalid email")
    private String email;
    @NotBlank
    private String role;
}
