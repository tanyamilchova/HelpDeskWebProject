package com.example.Help.Desk.model.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequestInfoDTO {
    private long id;
    private String description;
    private String status;
    private LocalDateTime dateSubmitted;
    private long projectId;
    private long teamMemberId;
}



