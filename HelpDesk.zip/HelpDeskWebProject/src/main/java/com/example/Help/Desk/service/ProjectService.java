package com.example.Help.Desk.service;

import com.example.Help.Desk.model.DTOs.*;
import com.example.Help.Desk.model.entities.Employee;
import com.example.Help.Desk.model.entities.Project;
import com.example.Help.Desk.model.repositories.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class ProjectService extends AbstractService{
    @Autowired
    private ProjectRepository projectRepository;

    public ProjectInfoDTO createProject(ProjectDTO createProjectDTO, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Employee teamLead=getValidEmployeeForPosition(createProjectDTO.getTeamLeadId(),RoleTypes.TEAM_LEAD);
        Project project=mapper.map(createProjectDTO,Project.class);
        project.setEmployee(teamLead);
        projectRepository.save(project);
        ProjectInfoDTO projectInfoDTO=mapper.map(project,ProjectInfoDTO.class);
        projectInfoDTO.setTeam_lead_id(teamLead.getId());
        return projectInfoDTO;
    }

    public ProjectInfoDTO editProject(long projectId, long loggedId, ProjectDTO editProjectDTO) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Project project=getIfPresent(projectRepository.findById(projectId));
        Employee teamLead=getValidEmployeeForPosition(editProjectDTO.getTeamLeadId(),RoleTypes.TEAM_LEAD);
        project.setName(editProjectDTO.getName());
        project.setDescription(editProjectDTO.getDescription());
        project.setEmployee(teamLead);
        projectRepository.save(project);
        ProjectInfoDTO projectInfoDTO=mapper.map(project,ProjectInfoDTO.class);
        projectInfoDTO.setTeam_lead_id(teamLead.getId());
        return projectInfoDTO;
    }

    public void deleteProject(long projectId, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Project project=getIfPresent(projectRepository.findById(projectId));
        projectRepository.delete(project);
    }

    public ProjectInfoDTO getProjectById(long projectId, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Project project=getIfPresent(projectRepository.findById(projectId));
        return mapper.map(project,ProjectInfoDTO.class);
    }

    public Page<ProjectInfoDTO> getAllProjects(int page, int size, long loggedId) {
        authorizeEmployee(loggedId,RoleTypes.ADMIN);
        Pageable pageable = PageRequest.of(page,size);
        return projectRepository.getAllProjectsInfo(pageable)
                .map(project -> mapper.map(project, ProjectInfoDTO.class));
    }
}
