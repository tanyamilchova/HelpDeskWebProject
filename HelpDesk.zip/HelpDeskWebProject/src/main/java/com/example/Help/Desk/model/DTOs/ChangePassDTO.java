package com.example.Help.Desk.model.DTOs;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ChangePassDTO {
    @NotBlank(message = "Current password is required")
    private String currentPassword;
    @NotBlank(message = "Password is required")
    @Pattern(regexp ="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$",
            message = "Password must contain at least one letter, one number, and one special character " +
                    "and must be at least 8 characters long")
    private String newPassword;
    @NotBlank(message = "Please confirm password")
    private String confirmNewPassword;
}
